package com.example.new_bazaar_khata

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
